#
# TABLE STRUCTURE FOR: ci_companies
#

DROP TABLE IF EXISTS `ci_companies`;

CREATE TABLE `ci_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (9, 'Codeglamour2', 'codeglamour1@gmail.com', '44785566952', '27 new jersey - Level 58 - CA 444 United State ', '', '2017-12-29 10:12:53');
INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (8, 'Codeglamour', 'codeglamour1@gmail.com', '44785566952', '27 new jersey - Level 58 - CA 444 United State ', '', '2017-12-13 10:12:07');
INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (7, 'Codeglamour', 'codeglamour1@gmail.com', '44785566952', '27 new jersey - Level 58 - CA 444 United State ', '', '2017-12-13 07:12:18');
INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (6, 'Codeglamour', 'codeglamour1@gmail.com', '44785566952', '27 new jersey - Level 58 - CA 444  United State LLC', '', '2017-12-11 08:12:15');
INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (10, 'Codeglamour', 'codeglamour1@gmail.com', '44785566952', '27 new jersey - Level 58 - CA 444 United State ', '', '2018-01-02 02:01:40');
INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (11, 'Codeglamour', 'codeglamour1@gmail.com', '44785566952', '27 new jersey - Level 58 - CA 444 United State ', '', '2017-12-28 04:12:15');
INSERT INTO `ci_companies` (`id`, `name`, `email`, `mobile_no`, `address1`, `address2`, `created_date`) VALUES (12, 'Codeglamour', 'codeglamour1@gmail.com', '44785566952', '27 new jersey - Level 58 - CA 444 United State ', '', '2018-01-03 01:01:05');


#
# TABLE STRUCTURE FOR: ci_payments
#

DROP TABLE IF EXISTS `ci_payments`;

CREATE TABLE `ci_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `invoice_no` varchar(30) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `items_detail` longtext NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `total_tax` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `currency` varchar(20) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` varchar(30) NOT NULL,
  `client_note` longtext NOT NULL,
  `termsncondition` longtext NOT NULL,
  `due_date` date NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `ci_payments` (`id`, `admin_id`, `user_id`, `company_id`, `invoice_no`, `txn_id`, `items_detail`, `sub_total`, `total_tax`, `discount`, `grand_total`, `currency`, `payment_method`, `payment_status`, `client_note`, `termsncondition`, `due_date`, `created_date`, `updated_date`) VALUES (4, 3, 27, 9, 'INV-2001', '', 'a:5:{s:19:\"product_description\";a:1:{i:0;s:17:\"Samsung Galaxy S3\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:4:\"1000\";}s:3:\"tax\";a:1:{i:0;s:1:\"2\";}s:5:\"total\";a:1:{i:0;s:7:\"1000.00\";}}', '1000.00', '20.00', '5.00', '1015.00', 'USD', '', 'Paid', 'Will be delivered within next 24 hours', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2017-11-29', '2017-12-06', '2017-12-29');
INSERT INTO `ci_payments` (`id`, `admin_id`, `user_id`, `company_id`, `invoice_no`, `txn_id`, `items_detail`, `sub_total`, `total_tax`, `discount`, `grand_total`, `currency`, `payment_method`, `payment_status`, `client_note`, `termsncondition`, `due_date`, `created_date`, `updated_date`) VALUES (6, 3, 24, 11, 'INV-00012', '', 'a:5:{s:19:\"product_description\";a:2:{i:0;s:6:\"Module\";i:1;s:7:\"T-Shirt\";}s:8:\"quantity\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}s:5:\"price\";a:2:{i:0;s:3:\"100\";i:1;s:2:\"35\";}s:3:\"tax\";a:2:{i:0;s:1:\"0\";i:1;s:1:\"0\";}s:5:\"total\";a:2:{i:0;s:6:\"100.00\";i:1;s:5:\"70.00\";}}', '170.00', '0.00', '0.00', '170.00', 'USD', '', 'Unpaid', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2017-12-31', '2017-12-28', NULL);
INSERT INTO `ci_payments` (`id`, `admin_id`, `user_id`, `company_id`, `invoice_no`, `txn_id`, `items_detail`, `sub_total`, `total_tax`, `discount`, `grand_total`, `currency`, `payment_method`, `payment_status`, `client_note`, `termsncondition`, `due_date`, `created_date`, `updated_date`) VALUES (3, 3, 12, 8, 'inv-2002', '', 'a:5:{s:19:\"product_description\";a:1:{i:0;s:17:\"Samsung Galaxy S3\";}s:8:\"quantity\";a:1:{i:0;s:1:\"1\";}s:5:\"price\";a:1:{i:0;s:2:\"10\";}s:3:\"tax\";a:1:{i:0;s:1:\"2\";}s:5:\"total\";a:1:{i:0;s:5:\"10.00\";}}', '10.00', '0.20', '1.00', '9.20', 'USD', '', 'Paid', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2017-12-06', '2017-12-06', NULL);


#
# TABLE STRUCTURE FOR: ci_user_groups
#

DROP TABLE IF EXISTS `ci_user_groups`;

CREATE TABLE `ci_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (1, 'Member');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (2, 'Accountant');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (7, 'PHP Developer');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (6, 'Android');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (9, 'Test Bot');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (10, 'test');


#
# TABLE STRUCTURE FOR: ci_users
#

DROP TABLE IF EXISTS `ci_users`;

CREATE TABLE `ci_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `last_ip` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (3, 'admin', 'admin', 'admin', 'admin@admin.com', '12345', '$2y$10$qlAzDhBEqkKwP3OykqA7N.ZQk6T67fxD9RHfdv3zToxa9Mtwu9C/e', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 1, '', '2017-09-29 10:09:44', '2017-12-27 05:12:19');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (12, 'nauman', 'nauman', 'ahmed', 'naumanahmedcs@gmail.com', '3468548054', '$2y$10$qlAzDhBEqkKwP3OykqA7N.ZQk6T67fxD9RHfdv3zToxa9Mtwu9C/e', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 0, '', '2017-10-12 06:10:02', '2017-10-12 06:10:52');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (13, 'Mery', 'mery', 'john', 'john@gmai.com', '12345', '$2y$10$Og.oy267hEp47FdyBRWuDuLneeUyL7FoW0eWGfggoTQY3AEJXH0Aa', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 0, '', '2017-10-12 07:10:10', '2017-12-13 10:12:28');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (14, 'bashir', 'bashir', 'rana', 'bashir@gmail.com', '12345', '$2y$10$nlqjpuehgZZFTuzU4xXY/Ol5RiwkuuxyDFgwcjWtbXA82Bfzkds9W', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 0, 0, '', '2017-10-12 07:10:10', '2017-12-16 07:12:16');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (15, 'Codova', 'codova', 'cadova', 'cadova888@gmail.com', '12345', '$2y$10$EP1btWmMuJ52bsEQdjc63ecoCMsmsYa9u/B2ajRPiNGvBYn4UfbSC', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 0, '', '2017-10-12 07:10:10', '2017-12-16 07:12:46');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (31, 'dfgdfgdgdgfd', 'Abc', 'asdf', 'abc@anc.com', '95797', '$2y$10$AW.4mvJPomw5yHkma8aJce14X1TTm9kBdrpFSWTL0spiCbVdkFwXG', 'Ahana', 7, 0, 0, '', '2017-12-28 12:12:25', '2018-01-02 11:01:27');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (32, 'DDBot', 'DD', 'Bot', 'theddbot@gmail.com', '2848888545', '$2y$10$mCybbu3dGtcLBe8pVyVEYOeN9fjTILK/izWEAcSuHbvi7v/PeYHlK', '', 1, 1, 0, '', '2017-12-29 01:12:52', '2017-12-29 01:12:52');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (17, 'demo5', 'test', 'test', 'test3@gmail.com', '12345', '$2y$10$AQ5cMc9xwhufaiHbPlDasOY4EEgEifI.0jc2DIo1dS3AzBqkyoSdu', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 6, 1, 0, '', '2017-10-12 07:10:10', '2017-12-16 08:12:23');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (18, 'demo6', 'test', 'test', 'test4@gmail.com', '12345', '$2y$10$fJu14EYhbtIIPNX8USMon.6TO4qfP3EZZRL8ZUqJuylawW2x9.V9W', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 0, '', '2017-10-12 07:10:10', '2017-12-16 08:12:39');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (20, 'demo8', 'test', 'test', 'test11@gmail.com', '12345', '$2y$10$lJdgWoqIH4IpOOFHnVGkWeFmSFXvB7501O2VnZj6KGiBRCLq88VDm', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 2, 0, 0, '', '2017-10-12 07:10:10', '2017-12-16 08:12:14');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (21, 'demo9', 'test', 'test', 'test101@gmail.com', '12345', '$2y$10$/YBnUznli6P9yIcvP23Q4eNbURquLbVsRdKTBirloQdmjnXpARa8.', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 0, '', '2017-10-12 07:10:10', '2017-12-16 09:12:24');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (22, 'john', 'carry', 'carry', 'carry1021@gmai.com', '12345', '$2y$10$aIvIv2wPsHpoXb9.C9aJIuM12PWdUMlgGBOL3tjI5SrxrvA7mKSdS', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 0, 0, '', '2017-10-12 07:10:10', '2017-12-16 07:12:05');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (24, 'rubby', 'rubby', 'rubby', 'rubby@gmai.com', '12345', '$2y$10$CMTwx/rjfrZatgYSW0YTduNWGw.HGxm6mXRbnvEjNmA1OqolcAI5u', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 2, 1, 0, '', '2017-10-12 07:10:10', '2017-12-16 07:12:48');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (25, 'rizwan', 'rizwan', 'shahid', 'rizwan@gmail.com', '12345', '$2y$10$.GxTBP2tgkxxX6E2A.xjSOANcCnLPVq0T554CnF9VGcqKIWTRKj2K', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 6, 1, 0, '', '2017-10-13 09:10:37', '2017-12-11 09:12:42');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (26, 'Marry', 'Marry', 'Andorson', 'marry1221@gmail.com', '445624553523', '$2y$10$Z/fLpBagUG5HdgXhdzKs0.I71RWAWD1Ok6P0.9gU9fZwT5Ovw7U4C', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 0, '', '2017-10-15 06:10:36', '2017-10-15 06:10:01');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (27, 'Alxender', 'Alxender', 'Smith', 'smith@gmail.com', '188792243665', '$2y$10$k0pgV3cRSbKuGaBL.eIlAeCawoFzTEDs6D5.3Z2PR/3zFTJSsd852', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 2, 1, 0, '', '2017-10-15 07:10:35', '2017-12-27 09:12:09');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (28, 'ahmedqqqq', 'ahmed', 'nawaz', 'ahmednawaz@gmail.com', '11255255625562', '$2y$10$70XeK1SIaHtzO/tU09FZNOwlPD.SGGHVJTjBE2kUcW/lKx3VV.B7e', '27 new jersey - Level 58 - CA 444 \r\nUnited State ', 1, 1, 0, '', '2017-11-18 10:11:54', '2018-01-03 10:01:04');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (29, 'Imtiaz', 'ahmed', 'imtiaz', 'imtiaz@gmail.com', '032215554455', '$2y$10$GSbucN2.xGrMOfmbl4eABOiz.3lcVPD9vXFMfP2ik71n5QPpvCOAO', 'pakistan', 2, 1, 0, '', '2017-12-16 08:12:55', '2017-12-16 08:12:55');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (30, 'Hina', 'Shah', 'Hina', 'hina996@gmail.com', '03469548054', '$2y$10$tSM/oCyo1kPBTNG/Iiwm/.RWdqPdcvi1xzyhdlAbL6f8sW4XMkn32', 'pakistan', 7, 0, 0, '', '2017-12-16 09:12:21', '2017-12-19 11:12:27');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (33, 'FritsReseller', 'frits', 'gaw', 'gaw@gmail.com', '09227476123', '$2y$10$AigEa8/Mwe2bv9q4f4IeG.UjJUU2HTMWVdc6RgEIWTxdqfF/DXkb6', 'cebu', 1, 1, 0, '', '2017-12-30 08:12:03', '2017-12-30 08:12:03');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (34, 'dfsd', 'dsdkl', 'llk', 'llkl@lll.ccc', '3', '$2y$10$qPt8iJuQezX4eOXq3J1Pm.0ubFrrp6bkf7NjF4Ifhi7XZF/iEnl0C', 'dsdsd', 2, 1, 0, '', '2018-01-02 09:01:10', '2018-01-02 09:01:10');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_admin`, `last_ip`, `created_at`, `updated_at`) VALUES (35, 'testtest', 'testtest', 'testtest', 'testtest@free.fr', '06854487555', '$2y$10$uVOB.MXVNelG2DiUkgCJQOTnELgG7xmFrOfQ0ZTKH6H42E8ka/7wG', '', 1, 1, 0, '', '2018-01-04 11:01:16', '2018-01-04 11:01:16');


#
# TABLE STRUCTURE FOR: test_user
#

DROP TABLE IF EXISTS `test_user`;

CREATE TABLE `test_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `test_user` (`id`, `username`, `email`, `mobile_no`) VALUES (1, 'nauman', 'naumanahmedcs@gmail.com', '3468548054');
INSERT INTO `test_user` (`id`, `username`, `email`, `mobile_no`) VALUES (2, 'ahmed', 'ahmed@gmail.com', '445684332545');


